"""Download official PDFs and save reachable university pages as HTML."""

from __future__ import annotations

import csv
import re
import socket
import ssl
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests

ROOT = Path(__file__).resolve().parent
CSV_PATH = ROOT / "ALL_OFFICIAL_URLS.csv"
HTML_DIR = ROOT / "Websites"
PDF_DIR = ROOT / "Downloaded_PDFs"
LOG = ROOT / "download_log.txt"

UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)
PINNED: dict[str, str] = {}
HOST_DEAD: set[str] = set()
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": UA, "Accept": "*/*"})
_orig = socket.getaddrinfo


def _pinned(host, port, *args, **kwargs):
    ip = PINNED.get(host)
    if ip:
        port_n = 443 if port in (None, 0) else int(port)
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, port_n))]
    return _orig(host, port, *args, **kwargs)


socket.getaddrinfo = _pinned


def log(message: str) -> None:
    print(message, flush=True)
    with LOG.open("a", encoding="utf-8") as handle:
        handle.write(message + "\n")


def safe(text: str, limit: int = 80) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", text).strip("._")
    return (cleaned or "page")[:limit]


def host_of(url: str) -> str:
    return (urlparse(url).hostname or "").lower()


def tls_ip(host: str) -> str | None:
    try:
        infos = socket.getaddrinfo(host, 443, socket.AF_INET, socket.SOCK_STREAM)
    except Exception:
        return None
    ctx = ssl.create_default_context()
    seen = []
    for info in infos:
        ip = info[4][0]
        if ip in seen:
            continue
        seen.append(ip)
        raw = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
        raw.settimeout(8)
        try:
            raw.connect((ip, 443))
            ss = ctx.wrap_socket(raw, server_hostname=host)
            ss.settimeout(8)
            ss.sendall(f"HEAD / HTTP/1.1\r\nHost: {host}\r\nConnection: close\r\n\r\n".encode())
            data = ss.recv(40)
            ss.close()
            if data.startswith(b"HTTP/"):
                return ip
        except Exception:
            try:
                raw.close()
            except Exception:
                pass
    return None


class Links(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs: list[str] = []

    def handle_starttag(self, tag, attrs):
        attr = {k.lower(): v for k, v in attrs if v}
        for key in ("href", "src"):
            if key in attr:
                self.refs.append(attr[key])


def fetch(url: str, timeout=(8, 50)) -> tuple[int, str, str, bytes]:
    response = SESSION.get(url, timeout=timeout, allow_redirects=True, stream=True)
    chunks = []
    total = 0
    for chunk in response.iter_content(65536):
        if not chunk:
            continue
        total += len(chunk)
        if total > 80 * 1024 * 1024:
            response.close()
            raise RuntimeError("too large")
        chunks.append(chunk)
    return response.status_code, response.headers.get("content-type", ""), response.url, b"".join(chunks)


def is_pdf(url: str, ctype: str, data: bytes) -> bool:
    return data[:5] == b"%PDF" or "pdf" in ctype.lower() or urlparse(url).path.lower().endswith(".pdf")


def is_html(ctype: str, data: bytes) -> bool:
    sample = data.lstrip()[:20].lower()
    return "html" in ctype.lower() or sample.startswith(b"<!doctype") or sample.startswith(b"<html") or sample.startswith(b"<head")


def save_unique(folder: Path, name: str, data: bytes) -> Path:
    folder.mkdir(parents=True, exist_ok=True)
    path = folder / name
    if path.exists() and path.read_bytes() == data:
        return path
    if path.exists() and path.stat().st_size != len(data):
        path = folder / f"{Path(name).stem}_{len(data)}{Path(name).suffix}"
    path.write_bytes(data)
    return path


def main() -> None:
    LOG.write_text("", encoding="utf-8")
    rows = list(csv.DictReader(CSV_PATH.open(encoding="utf-8-sig")))
    hosts = sorted({host_of(row["Official URL"]) for row in rows})
    for host in hosts:
        ip = tls_ip(host)
        if ip:
            PINNED[host] = ip
            log(f"LIVE {host} {ip}")
        else:
            HOST_DEAD.add(host)
            log(f"DEAD {host}")

    saved_html = 0
    saved_pdf = 0
    seen: set[str] = set()
    queue: list[tuple[str, str, str]] = []
    for index, row in enumerate(rows, 1):
        queue.append((row["University"], f"{index:02d}_{safe(row['Resource title'])}", row["Official URL"].strip()))

    # Also save the English homepages of hosts that answer, one level of same-site HTML.
    extra_home = {
        "english.bit.edu.cn": ("BIT", "https://english.bit.edu.cn/"),
        "en.nuaa.edu.cn": ("NUAA", "https://en.nuaa.edu.cn/"),
        "studyat.nwpu.edu.cn": ("NPU", "https://studyat.nwpu.edu.cn/"),
    }
    for host, (uni, url) in extra_home.items():
        if host not in HOST_DEAD:
            queue.append((uni, safe(host + "_home"), url))

    hops = 0
    while queue and hops < 220:
        university, stem, url = queue.pop(0)
        if url in seen:
            continue
        seen.add(url)
        hops += 1
        host = host_of(url)
        if host in HOST_DEAD:
            log(f"skip dead {url}")
            continue
        log(f"[{hops}] {university} {url}")
        try:
            status, ctype, final, data = fetch(url)
        except Exception as exc:
            log(f"  fail {type(exc).__name__}")
            continue
        if status >= 400 or len(data) < 100:
            log(f"  http {status} {len(data)}")
            continue
        if is_pdf(final, ctype, data):
            name = safe(Path(urlparse(final).path).name or stem)
            if not name.lower().endswith(".pdf"):
                name += ".pdf"
            path = save_unique(PDF_DIR / university, name, data)
            saved_pdf += 1
            log(f"  pdf {path.name} {len(data)}")
            continue
        if not is_html(ctype, data):
            log(f"  other {ctype[:40]} {len(data)}")
            continue
        path = save_unique(HTML_DIR / university, stem + ".html", data)
        saved_html += 1
        log(f"  html {path.name} {len(data)}")
        if host_of(final) not in extra_home and host not in ("english.bit.edu.cn", "en.nuaa.edu.cn", "studyat.nwpu.edu.cn"):
            continue
        parser = Links()
        try:
            parser.feed(data.decode("utf-8", errors="replace"))
        except Exception:
            continue
        added = 0
        for raw in parser.refs:
            if added >= 30:
                break
            if not raw or raw.startswith(("javascript:", "mailto:", "#", "data:")):
                continue
            link = urljoin(final, raw.strip())
            if host_of(link) != host_of(final):
                continue
            lower = urlparse(link).path.lower()
            if ".pdf" in link.lower() or lower.endswith((".html", ".htm", "/")) or "download" in lower:
                if link not in seen:
                    queue.append((university, safe(Path(urlparse(link).path).name or "page"), link))
                    added += 1
    log(f"done html={saved_html} pdf={saved_pdf} dead_hosts={len(HOST_DEAD)}")


if __name__ == "__main__":
    main()
