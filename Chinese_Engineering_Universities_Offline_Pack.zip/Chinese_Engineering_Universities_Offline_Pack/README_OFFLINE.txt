CHINESE ENGINEERING UNIVERSITIES — OFFLINE RESEARCH PACK
Prepared: 9 November 2026

Start here: open Documents\index.html in a browser. It links to one document
for each university. Each document is also saved as a Word file (.docx) in the
same folder. Both open without an internet connection.

UNIVERSITIES
1. Beijing Institute of Technology (BIT) — 北京理工大学
2. Beihang University (BUAA) — 北京航空航天大学
3. Harbin Engineering University (HEU) — 哈尔滨工程大学
4. Harbin Institute of Technology (HIT) — 哈尔滨工业大学
5. Nanjing University of Aeronautics and Astronautics (NUAA) — 南京航空航天大学
6. Northwestern Polytechnical University (NPU) — 西北工业大学

DOCUMENTS
Documents\01_BIT_Beijing_Institute_of_Technology.html and .docx
Documents\02_Beihang_University.html and .docx
Documents\03_HEU_Harbin_Engineering_University.html and .docx
Documents\04_HIT_Harbin_Institute_of_Technology.html and .docx
Documents\05_NUAA_Nanjing_University_of_Aeronautics_and_Astronautics.html and .docx
Documents\06_NPU_Northwestern_Polytechnical_University.html and .docx

Each document has the university's history, faculties, research, campuses,
admissions documents, and links to the local PDF and HTML files.

SAVED WEBSITE PAGES
Websites\BIT\     English gallery, autumn 2026 photos, campus directory
Websites\NUAA\    Multimedia, campus photos, museums, campus map
Websites\NPU\     The international college site, including admissions,
                  scholarships, campus life, maps, brochures and guides
                  (about 150 HTML pages)

DOWNLOADED PDFs
Downloaded_PDFs\NUAA\20_International_Undergraduate_Admission_Brochure.pdf
Downloaded_PDFs\NPU\2026_Admission_Viewbook.pdf
Downloaded_PDFs\NPU\2026_Masters_and_PhD_Brochure.pdf
Downloaded_PDFs\NPU\Guide_for_International_Freshmen_2021.pdf
Downloaded_PDFs\NPU\FAQ_New_International_Students_2021.pdf
Downloaded_PDFs\NPU\FAQ_New_International_Students_2022.pdf

Photographs taken from the saved pages are in Downloaded_Pictures\.

WHAT COULD NOT BE DOWNLOADED
Beihang, HEU, HIT, and the main Chinese sites of BIT and NUAA did not complete
a connection from this computer, so their original pages and PDF brochures are
not in the folders. Their written documents are still here, with the official
addresses listed at the end of each file. On a network that can open those
sites, run:

    python download_references.py
    python build_university_documents.py

OTHER MATERIAL
Chinese_Engineering_Universities_Offline_Research_Workbook.xlsx
  Comparison workbook. The Downloaded Copies sheet records the first capture.
ALL_OFFICIAL_URLS.csv
  The source list of official addresses.
Offline_MHTML\
  Earlier written profiles. The new documents in Documents\ are the ones to read.
Pictures\
  Six illustrative drawings. They are not official photographs.
  Official photographs that were saved are in Downloaded_Pictures\.

Admissions rules, fees and statistics change. Check the university before
relying on a figure.
