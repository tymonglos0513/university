"""Save official university pages, PDFs, and pictures for offline use.

Hosts that complete a TLS handshake are downloaded directly. Each HTML page
is stored with its CSS and images and also packed as an MHTML file. Hosts
that do not connect are looked up on the Internet Archive.
"""

from __future__ import annotations

import csv
import re
import socket
import ssl
import time
from email import encoders
from email.mime.base import MIMEBase
from email.mime.multipart import MIMEMultipart
from email.mime.text import MIMEText
from html.parser import HTMLParser
from pathlib import Path
from urllib.parse import urljoin, urlparse

import requests

ROOT = Path(__file__).resolve().parent
CSV_PATH = ROOT / "ALL_OFFICIAL_URLS.csv"
MHTML_DIR = ROOT / "Captured_Websites"
PDF_DIR = ROOT / "Downloaded_PDFs"
PIC_DIR = ROOT / "Downloaded_Pictures"
OTHER_DIR = ROOT / "Downloaded_Files"
MANIFEST = ROOT / "CAPTURE_MANIFEST.csv"
LOG_PATH = ROOT / "capture_log.txt"

PINNED = {
    "en.nuaa.edu.cn": "163.171.157.57",
    "english.bit.edu.cn": "138.113.92.219",
    "studyat.nwpu.edu.cn": "154.93.109.6",
}
LIVE_HOSTS = set(PINNED)
EXTRA_ASSET_HOSTS = {"subsites.chinadaily.com.cn"}
UA = (
    "Mozilla/5.0 (Windows NT 10.0; Win64; x64) "
    "AppleWebKit/537.36 (KHTML, like Gecko) Chrome/131.0.0.0 Safari/537.36"
)
MAX_BYTES = 80 * 1024 * 1024
ARCHIVE_BLOCKED = False

_orig_getaddrinfo = socket.getaddrinfo


def _pinned_getaddrinfo(host, port, *args, **kwargs):
    ip = PINNED.get(host)
    if ip:
        port_n = 443 if port in (None, 0) else int(port)
        return [(socket.AF_INET, socket.SOCK_STREAM, 6, "", (ip, port_n))]
    return _orig_getaddrinfo(host, port, *args, **kwargs)


socket.getaddrinfo = _pinned_getaddrinfo
SESSION = requests.Session()
SESSION.headers.update({"User-Agent": UA, "Accept": "*/*"})


def log(message: str) -> None:
    line = f"{time.strftime('%H:%M:%S')} {message}"
    print(line, flush=True)
    with LOG_PATH.open("a", encoding="utf-8") as handle:
        handle.write(line + "\n")


def safe_slug(text: str, limit: int = 80) -> str:
    cleaned = re.sub(r"[^A-Za-z0-9._-]+", "_", text).strip("._")
    return (cleaned or "file")[:limit]


def host_of(url: str) -> str:
    return (urlparse(url).hostname or "").lower()


def rel(path: Path | None) -> str:
    if path is None:
        return ""
    return str(path.relative_to(ROOT))


class RefParser(HTMLParser):
    def __init__(self):
        super().__init__()
        self.refs: list[str] = []

    def handle_starttag(self, tag, attrs):
        attr = {key.lower(): value for key, value in attrs if value}
        for key in ("href", "src"):
            if key in attr:
                self.refs.append(attr[key])
        if "srcset" in attr:
            self.refs.append(attr["srcset"].split(",")[0].strip().split(" ")[0])


def page_links(html: str, base: str) -> list[str]:
    parser = RefParser()
    try:
        parser.feed(html)
    except Exception:
        return []
    links = []
    for raw in parser.refs:
        if not raw or raw.startswith(("javascript:", "mailto:", "#", "data:")):
            continue
        links.append(urljoin(base, raw.strip()))
    return links


def css_links(css: str, base: str) -> list[str]:
    found = []
    for match in re.findall(r"url\(([^)]+)\)", css, flags=re.I):
        value = match.strip(" \"'")
        if not value or value.startswith("data:"):
            continue
        found.append(urljoin(base, value))
    return found


def preliminary(url: str) -> str:
    path = urlparse(url).path.lower()
    if ".pdf" in url.lower():
        return "pdf"
    if path.endswith((".html", ".htm", ".php", ".asp", ".aspx", ".jsp", "/")) or not Path(path).suffix:
        return "skip"
    return kind_of(url, "", b"")


def kind_of(url: str, content_type: str, data: bytes) -> str:
    if data[:5] == b"%PDF" or "pdf" in content_type.lower() or urlparse(url).path.lower().endswith(".pdf"):
        return "pdf"
    path = urlparse(url).path.lower()
    if path.endswith((".jpg", ".jpeg", ".png", ".gif", ".webp", ".svg", ".bmp", ".ico")) or content_type.lower().startswith("image/"):
        return "image"
    if path.endswith((".css",)) or "text/css" in content_type.lower():
        return "css"
    if path.endswith((".js",)) or "javascript" in content_type.lower():
        return "script"
    if path.endswith((".zip", ".rar", ".7z", ".doc", ".docx", ".xls", ".xlsx", ".ppt", ".pptx", ".psd", ".woff", ".woff2", ".ttf")):
        return "file"
    if "html" in content_type.lower() or data.lstrip()[:1] == b"<" or data.lstrip()[:15].lower().startswith(b"<!doctype"):
        return "html"
    return "file"


def fetch(url: str, timeout=(8, 25)) -> tuple[int, str, str, bytes]:
    response = SESSION.get(url, timeout=timeout, allow_redirects=True, stream=True)
    chunks = []
    total = 0
    for chunk in response.iter_content(65536):
        if not chunk:
            continue
        total += len(chunk)
        if total > MAX_BYTES:
            response.close()
            raise RuntimeError("file exceeded 80 MB")
        chunks.append(chunk)
    data = b"".join(chunks)
    return response.status_code, response.headers.get("content-type", ""), response.url, data


def save_bytes(folder: Path, university: str, name: str, data: bytes) -> Path:
    target = folder / university
    target.mkdir(parents=True, exist_ok=True)
    path = target / name
    path.write_bytes(data)
    return path


def content_type_for(url: str, header: str) -> str:
    if header:
        return header.split(";")[0].strip().lower()
    path = urlparse(url).path.lower()
    return {
        ".css": "text/css",
        ".js": "text/javascript",
        ".png": "image/png",
        ".jpg": "image/jpeg",
        ".jpeg": "image/jpeg",
        ".gif": "image/gif",
        ".webp": "image/webp",
        ".svg": "image/svg+xml",
        ".woff": "font/woff",
        ".woff2": "font/woff2",
        ".pdf": "application/pdf",
    }.get(Path(path).suffix, "application/octet-stream")


def build_mhtml(url: str, title: str, html: str, parts: list[tuple[str, str, bytes]]) -> str:
    message = MIMEMultipart("related")
    message["Subject"] = title
    message["Snapshot-Content-Location"] = url
    message["MIME-Version"] = "1.0"
    html_part = MIMEText(html, "html", "utf-8")
    html_part["Content-Location"] = url
    message.attach(html_part)
    for location, ctype, data in parts:
        if "/" not in ctype:
            ctype = "application/octet-stream"
        main, sub = ctype.split("/", 1)
        part = MIMEBase(main, sub)
        part.set_payload(data)
        encoders.encode_base64(part)
        part["Content-Location"] = location
        message.attach(part)
    return message.as_string()


def archive_snapshot(url: str) -> tuple[str, str] | None:
    global ARCHIVE_BLOCKED
    if ARCHIVE_BLOCKED:
        return None
    for attempt in range(3):
        if attempt:
            time.sleep(25 * attempt)
        try:
            response = SESSION.get(
                "https://web.archive.org/cdx/search/cdx",
                params={
                    "url": url,
                    "output": "json",
                    "fl": "timestamp,statuscode,mimetype",
                    "filter": "statuscode:200",
                    "limit": "-1",
                },
                timeout=(8, 25),
                headers={"User-Agent": UA, "Accept": "application/json"},
            )
        except Exception as exc:
            log(f"  archive lookup error {type(exc).__name__}")
            return None
        if response.status_code == 429:
            log(f"  archive rate limit, retry {attempt + 1}")
            continue
        if response.status_code != 200:
            log(f"  archive HTTP {response.status_code}")
            return None
        try:
            rows = response.json()
        except Exception:
            return None
        if len(rows) < 2:
            return None
        last = rows[-1]
        return last[0], last[2] if len(last) > 2 else ""
    ARCHIVE_BLOCKED = True
    log("  archive.org stayed rate-limited; later unreachable URLs will not be retried")
    return None


def allowed_asset(url: str, page_host: str) -> bool:
    host = host_of(url)
    if host in LIVE_HOSTS or host == page_host or host in EXTRA_ASSET_HOSTS:
        return True
    if host.endswith("archive.org") or host.endswith("web.archive.org"):
        return True
    return False


HOST_FAILURES: dict[str, int] = {}


def cached_file(university: str, name: str) -> Path | None:
    for folder in (PIC_DIR, PDF_DIR, OTHER_DIR, MHTML_DIR):
        path = folder / university / name
        if path.exists() and path.stat().st_size > 80:
            return path
    return None


def collect_assets(university: str, page_url: str, html: str, extras: list[str]) -> list[tuple[str, str, bytes]]:
    parts = []
    embedded = 0
    saved = 0
    seen: set[str] = set()
    queue = [(link, False) for link in page_links(html, page_url)]
    while queue and saved < 40:
        link, from_css = queue.pop(0)
        if link in seen:
            continue
        seen.add(link)
        asset_kind = preliminary(link)
        if asset_kind in ("skip", "html", "script"):
            continue
        if not allowed_asset(link, host_of(page_url)):
            continue
        if asset_kind not in ("pdf", "image", "css", "file"):
            continue
        if from_css and asset_kind not in ("image", "file", "css"):
            continue
        host = host_of(link)
        name_guess = safe_slug(Path(urlparse(link).path).name or "asset")
        if asset_kind == "pdf" and not name_guess.lower().endswith(".pdf"):
            name_guess += ".pdf"
        existing = cached_file(university, name_guess) if asset_kind in ("image", "pdf", "file") else None
        if existing:
            data = existing.read_bytes()
            final_url = link
            ctype = content_type_for(link, "")
            status = 200
            log(f"  cache {existing.name}")
        elif HOST_FAILURES.get(host, 0) >= 4:
            continue
        else:
            try:
                status, ctype, final_url, data = fetch(link)
                HOST_FAILURES[host] = 0
            except Exception as exc:
                HOST_FAILURES[host] = HOST_FAILURES.get(host, 0) + 1
                log(f"  skip {Path(urlparse(link).path).name} {type(exc).__name__} ({HOST_FAILURES[host]})")
                continue
        if status >= 400 or len(data) < 80:
            continue
        real_kind = kind_of(final_url, ctype, data)
        name = safe_slug(Path(urlparse(final_url).path).name or "asset")
        if real_kind == "pdf":
            if not name.lower().endswith(".pdf"):
                name += ".pdf"
            path = save_bytes(PDF_DIR, university, name, data)
            extras.append(rel(path))
            saved += 1
            log(f"  pdf {path.name} ({len(data)} bytes)")
            continue
        if real_kind == "image":
            path = save_bytes(PIC_DIR, university, name, data)
            extras.append(rel(path))
        elif real_kind == "file":
            path = save_bytes(OTHER_DIR, university, name, data)
            extras.append(rel(path))
        else:
            path = None
        saved += 1
        if real_kind in ("image", "css", "file") and len(data) <= 4_000_000 and embedded < 30:
            parts.append((final_url, content_type_for(final_url, ctype), data))
            embedded += 1
        if real_kind == "css" and embedded < 30:
            text = data.decode("utf-8", errors="replace")
            for child in css_links(text, final_url):
                if child not in seen:
                    queue.append((child, True))
        if path:
            log(f"  saved {path.name} ({len(data)} bytes)")
    return parts


def capture_html(university: str, stem: str, title: str, page_url: str, data: bytes, source: str, status: int, ctype: str) -> dict:
    html = data.decode("utf-8", errors="replace")
    if "<base " not in html.lower():
        html = re.sub(r"(?i)<head([^>]*)>", r'<head\1><base href="' + page_url + '">', html, count=1)
    extras: list[str] = []
    html_path = save_bytes(OTHER_DIR, university, stem + ".html", html.encode("utf-8"))
    extras.append(rel(html_path))
    parts = collect_assets(university, page_url, html, extras)
    mhtml_path = None
    try:
        payload = build_mhtml(page_url, title, html, parts)
        mhtml_path = save_bytes(MHTML_DIR, university, stem + ".mhtml", payload.encode("utf-8"))
        log(f"  mhtml {mhtml_path.name} ({mhtml_path.stat().st_size} bytes, {len(parts)} embedded)")
    except Exception as exc:
        log(f"  mhtml build failed {type(exc).__name__}: {exc}")
    return {
        "status": "saved" if mhtml_path else "html_only",
        "http_status": status,
        "content_type": ctype.split(";")[0],
        "source": source,
        "mhtml": rel(mhtml_path),
        "saved_file": rel(html_path),
        "extra_files": " | ".join(extras[1:]),
        "error": "",
    }


def capture_live(index: int, university: str, title: str, url: str) -> dict:
    status, ctype, final_url, data = fetch(url, timeout=(8, 40))
    kind = kind_of(final_url, ctype, data)
    stem = f"{index:02d}_{safe_slug(title)}"
    if kind == "html":
        return capture_html(university, stem, title, final_url, data, "live", status, ctype)
    if kind == "pdf":
        path = save_bytes(PDF_DIR, university, stem + ".pdf", data)
    elif kind == "image":
        suffix = Path(urlparse(final_url).path).suffix or ".img"
        path = save_bytes(PIC_DIR, university, stem + suffix.lower(), data)
    else:
        suffix = Path(urlparse(final_url).path).suffix or ".bin"
        path = save_bytes(OTHER_DIR, university, stem + suffix.lower(), data)
    log(f"  saved {kind} {path.name} ({len(data)} bytes)")
    return {
        "status": "saved" if status < 400 else f"http_{status}",
        "http_status": status,
        "content_type": ctype.split(";")[0],
        "source": "live",
        "mhtml": "",
        "saved_file": rel(path),
        "extra_files": "",
        "error": "",
    }


def capture_archive(index: int, university: str, title: str, url: str) -> dict:
    snap = archive_snapshot(url)
    if not snap:
        if ARCHIVE_BLOCKED:
            return {
                "status": "unreachable",
                "http_status": "",
                "content_type": "",
                "source": "",
                "mhtml": "",
                "saved_file": "",
                "extra_files": "",
                "error": "host did not complete TLS; archive.org rate-limited this lookup",
            }
        return {
            "status": "unreachable",
            "http_status": "",
            "content_type": "",
            "source": "",
            "mhtml": "",
            "saved_file": "",
            "extra_files": "",
            "error": "host did not complete TLS and Internet Archive has no snapshot",
        }
    timestamp, mimetype = snap
    replay = f"https://web.archive.org/web/{timestamp}/{url}"
    log(f"  archive {timestamp}")
    status, ctype, final_url, data = fetch(replay, timeout=(10, 60))
    stem = f"{index:02d}_{safe_slug(title)}"
    if kind_of(url, mimetype or ctype, data) == "pdf" or data[:5] == b"%PDF":
        path = save_bytes(PDF_DIR, university, stem + ".pdf", data)
        log(f"  archived pdf {path.name} ({len(data)} bytes)")
        return {
            "status": "saved",
            "http_status": status,
            "content_type": "application/pdf",
            "source": f"archive.org:{timestamp}",
            "mhtml": "",
            "saved_file": rel(path),
            "extra_files": "",
            "error": "",
        }
    return capture_html(university, stem, title, final_url, data, f"archive.org:{timestamp}", status, ctype)


def write_manifest(rows: list[dict]) -> None:
    fields = [
        "index", "university", "category", "title", "url", "status", "http_status",
        "content_type", "source", "mhtml", "saved_file", "extra_files", "error",
    ]
    with MANIFEST.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields)
        writer.writeheader()
        writer.writerows(rows)


def load_rows() -> list[dict]:
    with CSV_PATH.open(encoding="utf-8-sig", newline="") as handle:
        return list(csv.DictReader(handle))


def main() -> None:
    LOG_PATH.write_text("", encoding="utf-8")
    for folder in (MHTML_DIR, PDF_DIR, PIC_DIR, OTHER_DIR):
        folder.mkdir(exist_ok=True)
    rows = load_rows()
    ordered = list(enumerate(rows, start=1))
    ordered.sort(key=lambda item: (0 if host_of(item[1]["Official URL"].strip()) in LIVE_HOSTS else 1, item[0]))
    log(f"loaded {len(rows)} URLs")
    manifest: list[dict] = []
    for index, row in ordered:
        url = row["Official URL"].strip()
        university = row["University"].strip()
        title = row["Resource title"].strip()
        record = {
            "index": index,
            "university": university,
            "category": row["Resource category"].strip(),
            "title": title,
            "url": url,
            "status": "",
            "http_status": "",
            "content_type": "",
            "source": "",
            "mhtml": "",
            "saved_file": "",
            "extra_files": "",
            "error": "",
        }
        log(f"[{index}/69] {university} {title}")
        try:
            if host_of(url) in LIVE_HOSTS:
                record.update(capture_live(index, university, title, url))
            else:
                record.update(capture_archive(index, university, title, url))
        except Exception as exc:
            record["status"] = "error"
            record["error"] = f"{type(exc).__name__}: {exc}"
            log(f"  ERROR {record['error']}")
        manifest.append(record)
        write_manifest(sorted(manifest, key=lambda item: int(item["index"])))
    saved = sum(1 for item in manifest if item["status"] in ("saved", "html_only"))
    log(f"done saved={saved} unreachable={sum(1 for item in manifest if item['status']=='unreachable')} errors={sum(1 for item in manifest if item['status']=='error')}")


if __name__ == "__main__":
    main()
