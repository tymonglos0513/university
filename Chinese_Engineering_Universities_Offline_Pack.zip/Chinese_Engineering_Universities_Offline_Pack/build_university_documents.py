"""Build one offline document per university, in HTML and Word."""

from __future__ import annotations

import re
import shutil
from html import escape
from pathlib import Path
from urllib.parse import urlparse

from docx import Document
from docx.enum.text import WD_ALIGN_PARAGRAPH
from docx.shared import Inches, Pt, RGBColor

ROOT = Path(__file__).resolve().parent
DOC_DIR = ROOT / "Documents"
WEB_DIR = ROOT / "Websites"
PIC_DIR = ROOT / "Downloaded_Pictures"
PDF_DIR = ROOT / "Downloaded_PDFs"
SAVED_HTML = ROOT / "Downloaded_Files"

RENAMES = {
    "BIT": {
        "33_Official_Photo_Gallery.html": "Photo_Gallery.html",
        "34_Autumn_2026_Campus_Photographs.html": "Autumn_2026_Campus_Photographs.html",
        "48_Campus_Directory_and_Locations.html": "Campuses.html",
    },
    "NUAA": {
        "41_Official_Multimedia_Centre.html": "Multimedia_Centre.html",
        "42_Campus_and_Student_Life_Photographs.html": "Campus_and_Student_Life.html",
        "43_University_Museums_and_Campus_Facilities.html": "Museums_and_Facilities.html",
        "57_English_Campus_Map_Page.html": "Campus_Map.html",
        "66_Official_Multimedia_Centre.html": "Multimedia_Centre_Videos.html",
        "67_2021_Image_Film_The_Answer.html": "Image_Film_The_Answer.html",
    },
    "NPU": {
        "22_2026_Admission_Viewbook.html": "2026_Admission_Viewbook.html",
        "23_Official_Admission_Brochure_Archive.html": "Brochure_Archive.html",
        "24_2027_Undergraduate_Program_Guide.html": "2027_Undergraduate_Program_Guide.html",
        "25_2026_Master_s_and_PhD_Brochure.html": "2026_Masters_and_PhD_Brochure.html",
        "58_Youyi_and_Chang_an_Campus_Maps.html": "Campus_Maps.html",
        "68_Official_Video_Centre.html": "Video_Centre.html",
    },
}


def blocks_bit():
    return [
        ("h2", "Identity"),
        ("p", "Beijing Institute of Technology (北京理工大学, BIT) is a science and engineering university in Beijing, associated with the Ministry of Industry and Information Technology. Its public identity is defence-related engineering together with mechanical, information, control and computer science. The English site used for international readers is english.bit.edu.cn."),
        ("table", ["Item", "Detail"], [
            ["Founded", "1940, in Yan'an"],
            ["Present name", "1988"],
            ["City", "Beijing"],
            ["Earlier names", "Moved to Beijing in 1949; Beijing Engineering College from 1952"],
            ["Scale reported by the university", "More than 5,800 faculty and staff; more than 30,000 full-time students"],
            ["Academic organisation", "22 professional schools, seven colleges, and eight newer educational research institutions"],
        ]),
        ("h2", "History"),
        ("ul", [
            "Founded in Yan'an in 1940, during the wartime period of China's engineering and defence education.",
            "Moved to Beijing in 1949.",
            "Became Beijing Engineering College in 1952, in the national reorganisation of higher education.",
            "Took the present name, Beijing Institute of Technology, in 1988.",
            "The institutional story is tied to China's defence-industrial and engineering development, which is why weapons science, vehicles, control and information sit beside the broader science faculties.",
        ]),
        ("h2", "Academic structure and research"),
        ("p", "The fields the university itself presents as strengths are mechanical engineering and vehicle engineering, aerospace science and technology, weapon science and technology, control science and engineering, information and communication engineering, computer science and technology, integrated circuit science and engineering, cyberspace security, optics and photonics, materials science, and physics."),
        ("p", "Research themes highlighted in the institutional profile include intelligent and bionic robotics, space adaptive optics, green energy, and industrial process control. Among the six universities in this pack, BIT is the one to open first for defence-oriented engineering, vehicles, robotics, control systems and information technology."),
        ("h2", "Campuses"),
        ("table", ["Campus", "Place", "Role"], [
            ["Zhongguancun", "Haidian, Beijing. No. 5 Zhongguancun South Street", "Historic central campus"],
            ["Liangxiang", "Fangshan, Beijing. No. 8 and No. 9 yards, Liangxiang East Road", "Large teaching and research campus"],
            ["Xishan", "Haidian, Beijing. No. 16 Lengquan East Road", "Research and specialised facilities"],
            ["Zhuhai", "Zhuhai", "International campus"],
            ["Jiaxing activity", "Jiaxing", "Includes the BIT–PoliTO Joint College"],
        ]),
        ("p", "Zhongguancun and Liangxiang have separate official campus-map PDFs. Those PDF addresses are on isc.bit.edu.cn and law.bit.edu.cn. Those hosts did not complete a connection from this computer, so the map files are not in the PDF folder. The English campus directory was saved and is linked below."),
        ("h2", "International documents"),
        ("ul", [
            "2026 International Student Admission Books: a collection page with general, undergraduate, graduate, exchange, pre-university and Chinese-language publications.",
            "2026 Graduate Admission Book: a direct PDF covering degree information, application documents, scholarships, programmes and tuition.",
            "The collection page and the graduate PDF are both on isc.bit.edu.cn, which did not connect. They are listed in the reference section with their official addresses.",
        ]),
        ("h2", "Photographs, video and identity"),
        ("p", "The English photo gallery and the November 2026 autumn campus article were saved as HTML. Photographs from those pages, including the snow-covered university motto stone, are in the pictures folder and embedded below. The official visual-identity system, which sets logo use, lettering, colours and signage, is on www.bit.edu.cn and did not connect. The official promotional video page is on the same host."),
        ("h2", "Where BIT sits among the six"),
        ("p", "Choose BIT when the question is defence-related engineering, vehicles, robotics, control, information or cybersecurity. Beihang is the more specialised aerospace university in the same city. HIT is the broader engineering university. HEU is the naval and underwater specialist."),
    ]


def blocks_beihang():
    return [
        ("h2", "Identity"),
        ("p", "Beihang University (北京航空航天大学) is the official English name. The historic English name is Beijing University of Aeronautics and Astronautics, and the abbreviation BUAA is still widely used. It is in Beijing and is associated with the Ministry of Industry and Information Technology. It is China's specialist university for aviation, aircraft and space technology."),
        ("table", ["Item", "Detail"], [
            ["Established", "25 October 1952"],
            ["How it was formed", "Merger of the aeronautical departments of eight Chinese universities"],
            ["Earlier names", "Beijing Institute of Aeronautics; Beijing University of Aeronautics and Astronautics"],
            ["City", "Beijing"],
            ["Address used by the International Division", "37 Xueyuan Road, Haidian District, Beijing 100191"],
            ["International email", "international@buaa.edu.cn"],
        ]),
        ("h2", "History"),
        ("ul", [
            "Established on 25 October 1952.",
            "Formed by combining the aeronautical departments of eight universities, which is why the school system is still organised around flight vehicles, propulsion, astronautics and the sciences that support them.",
            "Known first as Beijing Institute of Aeronautics, then internationally as Beijing University of Aeronautics and Astronautics.",
            "The official English name is now Beihang University. The emblem includes the year 1952, an open book, and abstract aircraft and orbital forms.",
        ]),
        ("h2", "Academic structure"),
        ("ul", [
            "School of Aeronautical Science and Engineering",
            "School of Astronautics",
            "School of Mechanical Engineering and Automation",
            "School of Energy and Power Engineering",
            "School of Computer Science and Engineering",
            "School of Automation Science and Electrical Engineering",
            "School of Electronic and Information Engineering",
            "School of Materials Science and Engineering",
            "School of Artificial Intelligence",
            "School of Software Engineering",
            "School of Cyberspace Security",
            "School of Space and Environment",
        ]),
        ("h2", "Research"),
        ("p", "The university's research profile identifies nine national key laboratories, four national engineering research centres, and more than 70 ministerial key laboratories and engineering research centres. Themes named in official research material include aircraft aerodynamics, aero-engine thermodynamics, flight-vehicle control, computational fluid dynamics, satellite navigation, aerospace materials, air-traffic management, and reliability and environmental engineering."),
        ("p", "Among the six universities, Beihang is the first stop for aircraft design, flight systems, propulsion, aerospace science and astronautics."),
        ("h2", "Campuses"),
        ("table", ["Campus", "Place", "Role"], [
            ["Xueyuan Road", "Haidian, Beijing", "Established research and teaching campus"],
            ["Shahe", "Changping, Beijing", "Large research and education campus"],
            ["Hangzhou International Campus", "Hangzhou, Zhejiang", "International and interdisciplinary education"],
        ]),
        ("p", "The global website presents the two Beijing campuses most clearly. The Hangzhou campus appears in current academic and international admissions material and should be treated as a third location, not as a substitute for Xueyuan Road or Shahe."),
        ("h2", "Documents and maps"),
        ("ul", [
            "2027 Master's Program for International Students: eligibility, language requirements, schedule, transcripts, supervisor acceptance, study plan, recommendation letters, programmes, tuition and accommodation. Page: is.buaa.edu.cn.",
            "2027 High-level Postgraduate Chinese Government Scholarship guide, on the same international site.",
            "2024–2025 Beihang University Fact Sheet, PDF. Exchange fact sheet: nomination deadlines, course load, insurance, dormitory rent and visa letters. The academic calendar in that edition runs through 2024–2025, so it is older than this pack.",
            "Institutional presentation PDF (2020) and illustrated brochure PDF (2017). Useful as historical overviews, not as current statistics.",
            "Xueyuan Road campus map PDF (2015 edition) and Shahe campus handbook and map PDF.",
        ]),
        ("p", "Those Beihang hosts did not complete a connection from this computer, so the PDF files themselves are not in the PDF folder. The official addresses are in the reference list at the end of this document."),
        ("h2", "Photographs, video and identity"),
        ("p", "The International School photo and video gallery is at is.buaa.edu.cn. News imagery is on the Global Beihang site, global.buaa.edu.cn/en/. The International Division office is open weekdays 08:00–12:00 and 14:00–18:00. The official emblem explanation is on buaa.edu.cn. None of these hosts connected during this download, so original logo files and gallery photographs could not be saved."),
        ("h2", "Where Beihang sits among the six"),
        ("p", "Beihang is the aerospace specialist. NUAA is the other aviation university, with a stronger civil-aviation and aircraft-manufacturing emphasis and its base in Nanjing. NPU combines aeronautics with astronautics and marine technology in Xi'an. BIT, also in Beijing, is broader and more defence- and information-oriented."),
    ]


def blocks_heu():
    return [
        ("h2", "Identity"),
        ("p", "Harbin Engineering University (哈尔滨工程大学, HEU) is in Harbin and is associated with the Ministry of Industry and Information Technology. Its distinguishing identity is naval architecture, marine engineering, underwater technology and nuclear engineering. It should not be confused with Harbin Institute of Technology, which is a much broader engineering university in the same city."),
        ("table", ["Item", "Detail"], [
            ["Founded", "1953, as the PLA Military Engineering Institute"],
            ["1970 name", "Harbin Shipbuilding Engineering Institute"],
            ["Present name", "1994, Harbin Engineering University"],
            ["Main address", "145 Nantong Street, Nangang District, Harbin 150001"],
            ["Telephone", "0086 (0451) 8251 9213"],
            ["Email shown on the English site", "heufao@hrbeu.edu.cn"],
            ["Chinese site", "www.hrbeu.edu.cn"],
        ]),
        ("h2", "History"),
        ("ul", [
            "Founded in 1953 as the PLA Military Engineering Institute.",
            "Renamed Harbin Shipbuilding Engineering Institute in 1970.",
            "Became Harbin Engineering University in 1994.",
            "That lineage is why shipbuilding, underwater acoustics and marine power are core faculties rather than side departments.",
        ]),
        ("h2", "Academic structure"),
        ("p", "HEU describes 27 colleges and schools, more than 40 scientific research institutions, and over 150 scientific research and teaching laboratories. Major units include:"),
        ("ul", [
            "College of Shipbuilding Engineering",
            "College of Aerospace and Civil Engineering",
            "College of Power and Energy Engineering",
            "College of Intelligent Systems Science and Engineering",
            "College of Underwater Acoustic Engineering",
            "College of Computer Science and Technology",
            "College of Mechanical and Electrical Engineering",
            "College of Information and Communication Engineering",
            "College of Materials Science and Chemical Engineering",
            "College of Nuclear Science and Technology",
            "College of Physics and Optoelectronic Engineering",
            "College of Mathematical Sciences",
        ]),
        ("h2", "Research"),
        ("ul", [
            "Naval architecture and marine engineering",
            "Underwater acoustic positioning and communication",
            "Underwater robots and autonomous underwater vehicles",
            "Marine power systems",
            "Nuclear engineering and nuclear technology",
            "Ship stabilisation and navigation",
            "Ocean exploration",
            "Intelligent control systems",
        ]),
        ("p", "In November 2026 the English site reported that HEU had hosted the International Atomic Energy Agency's Lise Meitner Programme, the first time a Chinese university had hosted that scheme, and that the 12th International Symposium on Harmonious Nuclear Power was held at the university. Those items match the nuclear and marine identity. The same homepage prints a building-area figure in square kilometres that is not a plausible campus size, so that statistic is not repeated here."),
        ("h2", "Campuses and research bases"),
        ("ul", [
            "Main campus: 145 Nantong Street, Nangang District, Harbin. The English map shows teaching buildings, dormitories, sports facilities, laboratories, libraries and campus roads.",
            "Qingdao Innovation and Development Base.",
            "Yantai Research Institute.",
            "Nanhai Institute.",
        ]),
        ("p", "Qingdao, Yantai and Nanhai are research or development bases. They are not automatic equivalents of the Harbin main campus."),
        ("h2", "Documents"),
        ("ul", [
            "2026 international admission notices, on studyheu.hrbeu.edu.cn, including undergraduate and postgraduate books, an international admission handbook, the Silk Road Chinese Government Scholarship handbook, Atomic Energy Scholarship information, and an international summer-school handbook.",
            "2024 International Student Admission Book, direct PDF. Older than the 2026 notices.",
            "2024 Master's and Doctoral Programs admission book, direct PDF. Also an older edition.",
        ]),
        ("p", "The HEU download hosts did not complete a connection from this computer, so those PDFs are not in the PDF folder. Use the 2026 notice archive, not the 2024 books, for current rules."),
        ("h2", "Photographs, video and identity"),
        ("ul", [
            "Campus landscape photographs: english.hrbeu.edu.cn.",
            "Chinese picture and video archive: www.hrbeu.edu.cn.",
            "Engineering Vision video centre: news.hrbeu.edu.cn, including the 2024 recruitment film Tuozhu.",
            "Visual identity and cultural symbols: colour and reverse emblems, wordmarks and motto typography, sometimes supplied as PSD, RAR or ZIP archives, on dwxcb.hrbeu.edu.cn.",
        ]),
        ("h2", "Where HEU sits among the six"),
        ("p", "HEU is the marine, naval and nuclear specialist. NPU also has a marine-technology cluster, but it is paired there with aeronautics and astronautics. HIT, the other Harbin university, is the comprehensive engineering institution. Do not treat HEU and HIT as two names for the same university."),
    ]


def blocks_hit():
    return [
        ("h2", "Identity"),
        ("p", "Harbin Institute of Technology (哈尔滨工业大学, HIT) is the comprehensive engineering university of the six. It is associated with the Ministry of Industry and Information Technology, is widely called a cradle of engineers, and operates three campuses: Harbin, Weihai and Shenzhen. It is not Harbin Engineering University."),
        ("table", ["Item", "Detail"], [
            ["Founded", "1920, in Harbin"],
            ["Key national university", "1954"],
            ["Project 211", "1996"],
            ["Project 985", "1999"],
            ["Merger", "Harbin University of Architecture, 2000"],
            ["Double First-Class", "Class A designation in 2017"],
            ["Study-at-HIT address", "No. 92 West Dazhi Street, Nangang District, Harbin 150001"],
            ["Study email", "StudyatHIT@hit.edu.cn"],
            ["Study telephones", "+86-451-86418461 and +86-451-86402455"],
        ]),
        ("h2", "History"),
        ("ul", [
            "Founded in Harbin in 1920.",
            "In 1951 it was one of two national model universities for adopting international higher-education practice. In 1954 it was among the first six institutions chosen for key national development.",
            "Entered Project 211 in 1996 and Project 985 in 1999.",
            "Merged with Harbin University of Architecture in 2000, which is why civil engineering and architecture sit inside an otherwise mechanical, aerospace and computing university.",
            "Designated a Class A Double First-Class university in 2017. As of the university's 2025 introduction, eight disciplines were in the latest Double First-Class phase.",
        ]),
        ("h2", "Three campuses"),
        ("table", ["Campus", "Province", "Role"], [
            ["Harbin", "Heilongjiang", "Historical campus and main engineering research centre"],
            ["Weihai", "Shandong", "Engineering and interdisciplinary education on the coast"],
            ["Shenzhen", "Guangdong", "Engineering, technology, innovation and industrial collaboration"],
        ]),
        ("p", "The international education material describes this as one university with three campuses, not as three separate institutes."),
        ("h2", "Academic and research strengths"),
        ("ul", [
            "Mechanical engineering, robotics and intelligent manufacturing",
            "Aerospace engineering, astronautics and satellite technology",
            "Computer science and advanced manufacturing",
            "Materials science",
            "Civil engineering, from the architecture merger",
            "Electrical engineering, control engineering and environmental science",
        ]),
        ("p", "The 2025 institutional introduction reports nine first-level national key disciplines and six second-level national key disciplines. In the Ministry of Education's fourth round of discipline evaluation, HIT reported 17 A-level disciplines. In the third round, 10 first-level disciplines were in the national top five, with mechanics first. The same introduction says HIT was the first Chinese university to establish a School of Astronautics, and it lists space-programme work including university satellites, space robotics, lunar exploration support and a space-environment simulation facility."),
        ("p", "The motto given by the university is to be strict in the qualifications for graduates and to make every effort in educating students. The crest uses an open book, the letters HIT, the year 1920, the historic main building and a gear."),
        ("h2", "Documents, maps and media"),
        ("ul", [
            "International admission portal: studyathit.hit.edu.cn, including undergraduate admission pages and scholarship notices. The portal's contact details were readable in November 2026; the site itself did not connect for a full HTML download.",
            "University introduction dated 2025 on en.hit.edu.cn.",
            "Interactive campus GIS map at map.hit.edu.cn, with buildings, libraries, accommodation, walking and vehicle navigation, and panoramic views. This is the most detailed map system of the six universities.",
            "Campus landscape gallery and multimedia centre on en.hit.edu.cn, including a 2026 admission video.",
            "Official emblem and motto explanation on www.hit.edu.cn.",
        ]),
        ("p", "HIT's servers did not complete a connection from this computer, so the introduction, map and gallery were not saved as original HTML, and no HIT PDF was stored."),
        ("h2", "Where HIT sits among the six"),
        ("p", "HIT is the broad engineering university: mechanical, robotics, manufacturing, materials, space technology, civil engineering and computer science, on three campuses. HEU is the specialist next door, in ships, underwater systems and nuclear technology. Beihang, NUAA and NPU are more specialised in flight and marine clusters."),
    ]


def blocks_nuaa():
    return [
        ("h2", "Identity"),
        ("p", "Nanjing University of Aeronautics and Astronautics (南京航空航天大学, NUAA) is a specialist engineering university in Nanjing, associated with the Ministry of Industry and Information Technology. Its centre of gravity is aviation, astronautics and civil aviation, with a large computer, electronics and artificial-intelligence layer around that core."),
        ("table", ["Item", "Detail"], [
            ["Founded", "1952"],
            ["National key university", "1978"],
            ["Project 211", "1996"],
            ["Double First-Class", "2017"],
            ["Colleges", "23"],
            ["Research institutions", "231, as reported by the university"],
            ["Students", "39,624"],
            ["Faculty and staff", "3,810"],
            ["Undergraduate programmes", "67"],
            ["National key laboratories", "12"],
            ["Statistics date", "Official figures published in June 2026"],
        ]),
        ("h2", "History"),
        ("ul", [
            "Founded in 1952.",
            "Designated a national key university in 1978.",
            "Among the first universities in China authorised to award doctoral degrees.",
            "Selected for Project 211 in 1996 and for Double First-Class in 2017.",
            "The university describes a long connection with China's aviation and aerospace industries.",
        ]),
        ("h2", "Academic structure"),
        ("ul", [
            "College of Aerospace Engineering",
            "College of Astronautics",
            "College of Civil Aviation",
            "College of Energy and Power Engineering",
            "College of Automation Engineering",
            "College of Electronic Information Engineering",
            "College of Mechanical and Electrical Engineering",
            "College of Materials Science and Technology",
            "College of Computer Science and Technology",
            "College of Software Engineering",
            "College of Artificial Intelligence",
            "College of Integrated Circuits",
            "College of Cybersecurity",
            "College of Economics and Management",
        ]),
        ("h2", "Research"),
        ("p", "Research areas named by the university include aircraft design and manufacturing, aerospace propulsion, aircraft structures and mechanics, flight control and automation, civil aviation and aviation safety, helicopter aeromechanics, unmanned aerial systems, aerospace materials, computer science and software, artificial intelligence, cybersecurity and integrated circuits."),
        ("p", "NUAA reports 12 national-level key laboratories, three national-level innovation centres, and more than 300 international university and research partners."),
        ("h2", "Campuses"),
        ("p", "The university describes itself as one university, four campuses and one innovation port."),
        ("table", ["Campus", "Place"], [
            ["Minggugong", "Qinhuai District, Nanjing"],
            ["Jiangjunlu", "Jiangning District, Nanjing"],
            ["Yangzijiang", "Nanjing"],
            ["Tianmuhu", "Liyang, Changzhou"],
            ["International Innovation Port", "Research and innovation facilities"],
        ]),
        ("p", "The campus also includes an aviation and aerospace museum and a history museum. The English campus-map page and the international-college map list were part of the source set. The English map page was saved. The international-college site, cie.nuaa.edu.cn, did not connect."),
        ("h2", "Documents"),
        ("ul", [
            "2026 International Postgraduate Admission Guide, on cie.nuaa.edu.cn. It describes more than 30 English-taught postgraduate programmes, tuition, accommodation, documents, supervisor letters, scholarships and English-language requirements. That host did not connect, so the guide page was not saved.",
            "International Undergraduate Admission Brochure, PDF, on en.nuaa.edu.cn. This file was downloaded. It is a 2025 brochure, so the 2026 postgraduate guide should be preferred for current postgraduate rules.",
        ]),
        ("h2", "Photographs and video"),
        ("p", "The English multimedia centre, a 2026 campus and student-life photo page, a museums and facilities page, and the page for the 2021 image film The Answer were saved as HTML. A campus photograph of the lake, zigzag bridge and pavilion is in the pictures folder. The multimedia archive also points to a 70th-anniversary film and a university promotional video. Those video files themselves were not downloaded."),
        ("h2", "Visual identity"),
        ("p", "The visual-identity portal is vi.nuaa.edu.cn, with a separate page of common downloadable identity files. That host did not connect, so approved logo files are not in this pack. Use that portal, rather than a third-party logo, when a mark is required."),
        ("h2", "Where NUAA sits among the six"),
        ("p", "NUAA is the aviation and civil-aviation university: aircraft structures, helicopters, flight control, propulsion and civil aviation, in Nanjing. Beihang is the Beijing aerospace specialist. NPU adds marine technology to aeronautics and astronautics. HIT is broader than any of the three."),
    ]


def blocks_npu():
    return [
        ("h2", "Identity"),
        ("p", "Northwestern Polytechnical University (西北工业大学, NPU) is in Xi'an and is associated with the Ministry of Industry and Information Technology. Its distinctive feature is the combination of three technological identities: aeronautics, astronautics and marine engineering. A useful shorthand used in the university's own organisation of fields is A–M–C: aerospace and marine; materials, mechanics and manufacturing; computer, communication and control."),
        ("table", ["Item", "Detail"], [
            ["Predecessor", "1938, National Northwestern Institute of Engineering"],
            ["Astronautics college", "1956, Xi'an Astronautic College"],
            ["Present university", "1957, by merger"],
            ["Later addition", "1970, aeronautics department of the former Harbin Military Engineering College"],
            ["Schools and colleges", "28"],
            ["Students", "More than 40,000"],
            ["Faculty", "More than 4,000"],
            ["Bachelor's first-level disciplines", "73"],
            ["Master's first-level disciplines", "39"],
            ["Doctoral first-level disciplines", "31"],
            ["ESI top 1 percent", "13 disciplines"],
            ["Figures dated", "University overview of 26 January 2026"],
        ]),
        ("h2", "History"),
        ("ul", [
            "1938: National Northwestern Institute of Engineering was founded.",
            "1956: Xi'an Astronautic College was established.",
            "1957: the institutions merged to form Northwestern Polytechnical University.",
            "1970: the aeronautics department of the former Harbin Military Engineering College joined. That is the historical link between NPU's flight work and the Harbin military-engineering tradition also visible at HEU.",
        ]),
        ("h2", "Three academic clusters"),
        ("table", ["Cluster", "What it covers"], [
            ["Aeronautics, astronautics and marine technology", "Aircraft and flight vehicles, spacecraft, marine engineering, underwater systems"],
            ["Materials, mechanics and mechanical engineering", "Advanced materials, engineering mechanics, mechanical design and manufacturing, composites"],
            ["Computer, communication and control", "Computer science, electronic and communication engineering, automation, artificial intelligence"],
        ]),
        ("h2", "Research"),
        ("p", "Fields named across the institutional profile include aerospace vehicle design, space technology, unmanned aerial systems, advanced propulsion, robotics, autonomous systems, marine and underwater technology, advanced materials, mechanics, computer science and artificial intelligence, software and cybersecurity, and intelligent manufacturing. NPU reports more than 300 international partners and 14 national-level international science and technology cooperation platforms."),
        ("h2", "Campuses"),
        ("table", ["Campus", "Address"], [
            ["Youyi", "127 West Youyi Road, Beilin District, Xi'an 710072"],
            ["Chang'an", "1 Dongxiang Road, Chang'an District, Xi'an 710129"],
            ["Kazakhstan", "An international branch initiative. It is not one of the two Xi'an campuses."],
        ]),
        ("p", "Youyi is the historic campus. Chang'an is the modern teaching and research campus. The International College map page has high-resolution maps of both Xi'an campuses, and that page was saved. An aerial campus photograph from the saved pages is in the pictures folder."),
        ("h2", "Documents that were downloaded"),
        ("ul", [
            "2026 Admission Viewbook, PDF, about 22 MB. The viewbook page and the PDF are both stored locally.",
            "2026 Master's and PhD programme brochure, PDF, about 5 MB. The announcement page and the PDF are both stored locally.",
            "Guide for International Freshmen 2021, PDF, about 17 MB.",
            "Frequently asked questions for new international students, 2021 and 2022 editions, PDFs. These are older student handbooks, not the 2026 admissions rules.",
            "2027 Undergraduate Program Guide. The full guide page was saved as HTML. It covers duration, application rounds, English-taught majors, eligibility and application documents. Some attached forms sit behind a verification-code page and were not downloaded.",
            "The brochure archive page was saved. It is the index for undergraduate, postgraduate, foundation and Chinese-language brochures.",
        ]),
        ("h2", "Video and identity"),
        ("p", "The International College video centre was saved. It holds a university introduction and school introductions, including computer science, software, automation, electronics, power and energy, and civil aviation. The 2025 international recruitment film Empowering Young Minds is on en.nwpu.edu.cn, which did not connect, so that film file is not in the pack. The official visual-identity system, including flag, emblem, wordmarks, colours and vector logos, is on news.nwpu.edu.cn and also did not connect."),
        ("h2", "Where NPU sits among the six"),
        ("p", "NPU is the university that deliberately combines aeronautics, astronautics and marine technology with materials and information. Beihang is the more purely aerospace university. HEU is the deeper naval and nuclear specialist. HIT is broader and less defined by a single industrial cluster."),
    ]


UNIVERSITIES = [
    {
        "key": "BIT",
        "slug": "01_BIT_Beijing_Institute_of_Technology",
        "title": "Beijing Institute of Technology",
        "chinese": "北京理工大学",
        "short": "BIT",
        "city": "Beijing",
        "line": "Defence, vehicles, robotics, control and information engineering.",
        "blocks": blocks_bit,
        "sources": [
            "https://english.bit.edu.cn/",
            "https://english.bit.edu.cn/gallery.html",
            "https://english.bit.edu.cn/campuses.html",
            "https://isc.bit.edu.cn/sylbt/c943f28225b14d3084e0049d049964c1.htm",
            "https://isc.bit.edu.cn/docs/2025-10/09d8791d614341d58870f6128f9c2b1c.pdf",
            "https://www.bit.edu.cn/gbxxgk/dqgz_sjb/vixx/index.htm",
        ],
    },
    {
        "key": "Beihang",
        "slug": "02_Beihang_University",
        "title": "Beihang University",
        "chinese": "北京航空航天大学",
        "short": "BUAA",
        "city": "Beijing",
        "line": "Aviation, aircraft, propulsion and astronautics.",
        "blocks": blocks_beihang,
        "sources": [
            "https://global.buaa.edu.cn/en/",
            "https://is.buaa.edu.cn/en/info/1029/3071.htm",
            "https://is.buaa.edu.cn/en/info/1416/3091.htm",
            "https://global.buaa.edu.cn/en/Beihang_University_Fact_Sheet_2024-2025.pdf",
            "https://global.buaa.edu.cn/en/20200714_Beihang_University.pdf",
            "https://global.buaa.edu.cn/en/Beihang_Brochure_2017.pdf",
            "https://buaa.edu.cn/xygk/jrbh0116old/bhxh.htm",
        ],
    },
    {
        "key": "HEU",
        "slug": "03_HEU_Harbin_Engineering_University",
        "title": "Harbin Engineering University",
        "chinese": "哈尔滨工程大学",
        "short": "HEU",
        "city": "Harbin",
        "line": "Naval architecture, underwater technology, marine power and nuclear engineering.",
        "blocks": blocks_heu,
        "sources": [
            "https://english.hrbeu.edu.cn/",
            "https://studyheu.hrbeu.edu.cn/en/Notice.htm",
            "https://studyheu.hrbeu.edu.cn/en/2024HEUInternationalStudentsAdmissionBook.pdf",
            "https://studyheu.hrbeu.edu.cn/en/2024HEUAdmissionBookforMasterandDoctoralPrograms.pdf",
            "https://english.hrbeu.edu.cn/Campus/Campuses.htm",
            "https://dwxcb.hrbeu.edu.cn/xxwhbsywhcp/main.psp",
        ],
    },
    {
        "key": "HIT",
        "slug": "04_HIT_Harbin_Institute_of_Technology",
        "title": "Harbin Institute of Technology",
        "chinese": "哈尔滨工业大学",
        "short": "HIT",
        "city": "Harbin, Weihai and Shenzhen",
        "line": "Comprehensive engineering, from mechanics and aerospace to computing and civil engineering.",
        "blocks": blocks_hit,
        "sources": [
            "https://en.hit.edu.cn/2025/0604/c11948a238198/page.htm",
            "https://studyathit.hit.edu.cn/",
            "https://map.hit.edu.cn/en/",
            "https://en.hit.edu.cn/11968/list.htm",
            "https://www.hit.edu.cn/11544/list.htm",
        ],
    },
    {
        "key": "NUAA",
        "slug": "05_NUAA_Nanjing_University_of_Aeronautics_and_Astronautics",
        "title": "Nanjing University of Aeronautics and Astronautics",
        "chinese": "南京航空航天大学",
        "short": "NUAA",
        "city": "Nanjing",
        "line": "Aircraft, helicopters, civil aviation, propulsion and flight control.",
        "blocks": blocks_nuaa,
        "sources": [
            "https://en.nuaa.edu.cn/",
            "https://en.nuaa.edu.cn/pdf/Undergraduate2.pdf",
            "https://cie.nuaa.edu.cn/_t1029/2025/1121/c16500a388279/page.htm",
            "https://en.nuaa.edu.cn/multimedia.html",
            "https://vi.nuaa.edu.cn/",
        ],
    },
    {
        "key": "NPU",
        "slug": "06_NPU_Northwestern_Polytechnical_University",
        "title": "Northwestern Polytechnical University",
        "chinese": "西北工业大学",
        "short": "NPU",
        "city": "Xi'an",
        "line": "Aeronautics, astronautics and marine technology, with materials and information.",
        "blocks": blocks_npu,
        "sources": [
            "https://en.nwpu.edu.cn/",
            "https://studyat.nwpu.edu.cn/info/1127/8041.htm",
            "https://studyat.nwpu.edu.cn/info/1127/7771.htm",
            "https://studyat.nwpu.edu.cn/info/1089/2124.htm",
            "https://studyat.nwpu.edu.cn/ABOUT_US/Campus_Maps.htm",
            "https://news.nwpu.edu.cn/xcb/index/xxsbxt.htm",
        ],
    },
]


def photos(key: str) -> list[Path]:
    folder = PIC_DIR / key
    if not folder.exists():
        return []
    files = [path for path in folder.iterdir() if path.is_file() and path.stat().st_size >= 40_000]
    files.sort(key=lambda path: path.stat().st_size, reverse=True)
    return files[:4]


def local_files(key: str) -> tuple[list[tuple[str, Path]], int]:
    found = []
    extra_pages = 0
    pdf_folder = PDF_DIR / key
    if pdf_folder.exists():
        for path in sorted(pdf_folder.glob("*.pdf")):
            found.append(("PDF", path))
    web_folder = WEB_DIR / key
    if web_folder.exists():
        for path in sorted(web_folder.glob("*.html")):
            if "download.jsp" in path.name:
                continue
            if re.fullmatch(r"\d+(?:\.htm)?", path.stem):
                extra_pages += 1
                continue
            found.append(("Saved website page", path))
    return found, extra_pages


def localize_images(html: str, key: str) -> str:
    names = {}
    folder = PIC_DIR / key
    if folder.exists():
        names = {path.name: path for path in folder.iterdir() if path.is_file()}

    def replace(match: re.Match) -> str:
        url = match.group(1)
        name = Path(urlparse(url).path).name
        if name in names:
            relative = Path("..") / "Downloaded_Pictures" / key / name
            return f'src="{relative.as_posix()}"'
        return match.group(0)

    return re.sub(r'src="([^"]+)"', replace, html, flags=re.I)


def copy_websites() -> None:
    for key, mapping in RENAMES.items():
        target = WEB_DIR / key
        target.mkdir(parents=True, exist_ok=True)
        source_dir = SAVED_HTML / key
        for old, new in mapping.items():
            source = source_dir / old
            if not source.exists():
                continue
            html = source.read_text(encoding="utf-8", errors="replace")
            (target / new).write_text(localize_images(html, key), encoding="utf-8")
    # Keep any HTML the downloader already placed in Websites/, and localize those too.
    if WEB_DIR.exists():
        for path in WEB_DIR.rglob("*.html"):
            key = path.parent.name
            if key not in RENAMES and key not in {item["key"] for item in UNIVERSITIES}:
                continue
            text = path.read_text(encoding="utf-8", errors="replace")
            path.write_text(localize_images(text, key), encoding="utf-8")


def render_html(uni: dict) -> str:
    parts = [
        "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\">",
        f"<title>{escape(uni['title'])}</title>",
        "<style>",
        "body{font-family:Georgia,serif;max-width:860px;margin:40px auto;padding:0 20px;color:#1c2430;line-height:1.55}",
        "h1{font-family:Segoe UI,sans-serif;font-size:32px;margin-bottom:0}",
        "h2{font-family:Segoe UI,sans-serif;font-size:22px;margin-top:32px;border-bottom:1px solid #d5dbe3;padding-bottom:4px}",
        ".sub{color:#445;margin-top:4px}",
        ".banner{background:#f4f7fb;padding:12px 14px;margin:18px 0}",
        "table{border-collapse:collapse;width:100%;margin:10px 0 16px}",
        "th,td{border:1px solid #d5dbe3;padding:6px 8px;vertical-align:top;text-align:left}",
        "th{background:#eef3f8}",
        "img{max-width:100%;margin:8px 0}",
        "figcaption{font-size:13px;color:#445;margin-top:-4px}",
        "a{color:#0b4f8a}",
        "</style></head><body>",
        f"<h1>{escape(uni['title'])}</h1>",
        f"<p class=\"sub\">{escape(uni['chinese'])} · {escape(uni['short'])} · {escape(uni['city'])}</p>",
        f"<div class=\"banner\">{escape(uni['line'])}<br>Offline research document, 9 November 2026. Figures come from university publications and sites. Check the university before using a number for an application.</div>",
    ]
    for block in uni["blocks"]():
        kind = block[0]
        if kind == "h2":
            parts.append(f"<h2>{escape(block[1])}</h2>")
        elif kind == "p":
            parts.append(f"<p>{escape(block[1])}</p>")
        elif kind == "ul":
            parts.append("<ul>" + "".join(f"<li>{escape(item)}</li>" for item in block[1]) + "</ul>")
        elif kind == "table":
            headers, rows = block[1], block[2]
            head = "".join(f"<th>{escape(cell)}</th>" for cell in headers)
            body = "".join("<tr>" + "".join(f"<td>{escape(cell)}</td>" for cell in row) + "</tr>" for row in rows)
            parts.append(f"<table><tr>{head}</tr>{body}</table>")
    shots = photos(uni["key"])
    if shots:
        parts.append("<h2>Campus photographs saved with this pack</h2>")
        for path in shots:
            relative = Path("..") / "Downloaded_Pictures" / uni["key"] / path.name
            parts.append(f"<figure><img src=\"{relative.as_posix()}\" alt=\"Campus photograph\"><figcaption>{escape(path.name)}</figcaption></figure>")
    files, extra_pages = local_files(uni["key"])
    parts.append("<h2>Files stored on this computer</h2>")
    if files:
        parts.append("<ul>")
        for label, path in files:
            relative = Path("..") / path.relative_to(ROOT)
            parts.append(f"<li>{escape(label)}: <a href=\"{relative.as_posix()}\">{escape(path.name)}</a></li>")
        parts.append("</ul>")
        if extra_pages:
            parts.append(
                f"<p>{extra_pages} further pages from the same site are saved as HTML in the Websites/{escape(uni['key'])} folder.</p>"
            )
    else:
        parts.append("<p>No original PDF or website HTML for this university was stored. The official sites did not complete a connection from this computer.</p>")
    parts.append("<h2>Official addresses</h2><ul>")
    for url in uni["sources"]:
        parts.append(f"<li>{escape(url)}</li>")
    parts.append("</ul><p>Opening an official address needs an internet connection. The files linked above do not.</p></body></html>")
    return "".join(parts)


def add_runs(paragraph, text: str) -> None:
    paragraph.add_run(text)


def render_docx(uni: dict, html_name: str) -> None:
    document = Document()
    normal = document.styles["Normal"]
    normal.font.name = "Calibri"
    normal.font.size = Pt(11)
    title = document.add_heading(uni["title"], 0)
    title.alignment = WD_ALIGN_PARAGRAPH.LEFT
    sub = document.add_paragraph(f"{uni['chinese']}  ·  {uni['short']}  ·  {uni['city']}")
    sub.runs[0].italic = True
    banner = document.add_paragraph(uni["line"])
    banner.runs[0].bold = True
    note = document.add_paragraph(
        "Offline research document, 9 November 2026. Figures come from university publications and sites. "
        "Check the university before using a number for an application. "
        f"The same text is in {html_name}, which opens in a browser without Word."
    )
    for run in note.runs:
        run.font.color.rgb = RGBColor(0x44, 0x55, 0x66)
        run.font.size = Pt(10)
    for block in uni["blocks"]():
        kind = block[0]
        if kind == "h2":
            document.add_heading(block[1], level=1)
        elif kind == "p":
            document.add_paragraph(block[1])
        elif kind == "ul":
            for item in block[1]:
                document.add_paragraph(item, style="List Bullet")
        elif kind == "table":
            headers, rows = block[1], block[2]
            table = document.add_table(rows=1, cols=len(headers))
            table.style = "Table Grid"
            for index, header in enumerate(headers):
                table.rows[0].cells[index].text = header
            for row in rows:
                cells = table.add_row().cells
                for index, value in enumerate(row):
                    cells[index].text = value
            document.add_paragraph()
    shots = photos(uni["key"])
    if shots:
        document.add_heading("Campus photographs saved with this pack", level=1)
        for path in shots:
            document.add_picture(str(path), width=Inches(6.2))
            caption = document.add_paragraph(path.name)
            caption.runs[0].italic = True
            caption.runs[0].font.size = Pt(9)
    document.add_heading("Files stored on this computer", level=1)
    files, extra_pages = local_files(uni["key"])
    if files:
        for label, path in files:
            document.add_paragraph(f"{label}: {path.relative_to(ROOT)}", style="List Bullet")
        if extra_pages:
            document.add_paragraph(
                f"{extra_pages} further pages from the same site are saved as HTML in Websites/{uni['key']}."
            )
    else:
        document.add_paragraph(
            "No original PDF or website HTML for this university was stored. "
            "The official sites did not complete a connection from this computer."
        )
    document.add_heading("Official addresses", level=1)
    for url in uni["sources"]:
        document.add_paragraph(url, style="List Bullet")
    document.add_paragraph("Opening an official address needs an internet connection. The local files listed above do not.")
    document.save(DOC_DIR / f"{uni['slug']}.docx")


def write_index(entries: list[tuple[str, str, str]]) -> None:
    items = []
    for title, html_name, docx_name in entries:
        items.append(
            f"<li><a href=\"{escape(html_name)}\">{escape(title)}</a> "
            f"(<a href=\"{escape(docx_name)}\">Word</a>)</li>"
        )
    page = (
        "<!DOCTYPE html><html lang=\"en\"><head><meta charset=\"utf-8\">"
        "<title>University documents</title>"
        "<style>body{font-family:Segoe UI,sans-serif;max-width:760px;margin:40px auto;padding:0 20px;line-height:1.5}</style>"
        "</head><body><h1>University documents</h1>"
        "<p>One document for each university. The HTML file opens in a browser. The Word file opens in Microsoft Word. "
        "Both work without an internet connection. Photographs, saved website pages and downloaded PDFs are linked from inside each document.</p><ul>"
        + "".join(items)
        + "</ul><p>Saved website pages are in the Websites folder. PDFs are in Downloaded_PDFs.</p></body></html>"
    )
    (DOC_DIR / "index.html").write_text(page, encoding="utf-8")


def main() -> None:
    DOC_DIR.mkdir(exist_ok=True)
    copy_websites()
    entries = []
    for uni in UNIVERSITIES:
        html_name = uni["slug"] + ".html"
        docx_name = uni["slug"] + ".docx"
        (DOC_DIR / html_name).write_text(render_html(uni), encoding="utf-8")
        render_docx(uni, html_name)
        entries.append((uni["title"], html_name, docx_name))
        print("wrote", html_name, "and", docx_name)
    write_index(entries)
    print("index ready")


if __name__ == "__main__":
    main()
